<?php 
mysqli_close($db_server);
?>