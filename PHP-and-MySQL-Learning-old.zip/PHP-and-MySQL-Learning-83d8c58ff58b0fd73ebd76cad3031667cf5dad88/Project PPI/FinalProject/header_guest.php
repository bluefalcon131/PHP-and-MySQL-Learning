<div id="header">
                    <div id = "logo">
                        <a href="index.php"><img src="images/logo.png" width="100%" alt="PPI Greater Leeds Logo"></a>
                    </div>
                    <div class="main-navbar" id="main-navbar">
                        <a href="register.php">Register</a>
                        <a href="index.php">Log In</a>
                    </div>
                 </div>