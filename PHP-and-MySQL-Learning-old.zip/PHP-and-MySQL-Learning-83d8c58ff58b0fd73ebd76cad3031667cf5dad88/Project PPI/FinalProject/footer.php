<?php
echo "<p>© 2019</p>" . "<a href="'www.corinagunawidjaja.myportfolio.com'">Corina Gunawidjaja</a>";
?>