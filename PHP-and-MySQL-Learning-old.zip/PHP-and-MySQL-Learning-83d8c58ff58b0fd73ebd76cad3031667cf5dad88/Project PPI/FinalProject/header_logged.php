<div id="header">
    <div id = "logo">
        <a href="home.php"><img src="images/logo.png" width="100%" alt="PPI Greater Leeds Logo"></a>
    </div>
    <div class="main-navbar" id="main-navbar">
        <a href="account.php">Your Account (<?php echo $_SESSION['username'] ?>)</a>
        <a href="forum.php">Forum</a>\
        <a href="search.php">Member Search</a>
        <a href="home.php">Home</a>
    </div>
</div>